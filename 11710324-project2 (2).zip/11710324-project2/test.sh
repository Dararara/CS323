make clean
make
./bin/splc test/test_11710324_1.spl
./bin/splc test/test_11710324_2.spl
./bin/splc test/test_11710324_3.spl
./bin/splc test/test_11710324_4.spl
./bin/splc test/test_11710324_5.spl
./bin/splc test/test_11710324_6.spl
./bin/splc test/test_11710324_7.spl
./bin/splc test/test_11710324_8.spl
./bin/splc test/test_11710324_9.spl
./bin/splc test/test_11710324_10.spl

diff test/test_11710324_1.out test_std/test_11710324_1.out
diff test/test_11710324_2.out test_std/test_11710324_2.out
diff test/test_11710324_3.out test_std/test_11710324_3.out
diff test/test_11710324_4.out test_std/test_11710324_4.out
diff test/test_11710324_5.out test_std/test_11710324_5.out
diff test/test_11710324_6.out test_std/test_11710324_6.out
diff test/test_11710324_7.out test_std/test_11710324_7.out
diff test/test_11710324_8.out test_std/test_11710324_8.out
diff test/test_11710324_9.out test_std/test_11710324_9.out
diff test/test_11710324_10.out test_std/test_11710324_10.out