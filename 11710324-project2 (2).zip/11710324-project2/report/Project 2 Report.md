# Project 2 Report

### Design and Implementation

#### 建立语法树

为了实现语义分析, 第一步我们需要做的是像project1一样解析整个程序源代码并且建一棵树, 但是这里根据假设, 我们不需要做语法错误检测, 省去了很多麻烦.

这次的project我把之前的项目迁移到了c++上面, 基本是推倒重来, 所以并没有复用之前的错误检测代码, 而是直接忽略掉这一部分内容

我通过一个AST_Node的类, 建立了一个树

 ```c++
class ASTNode{
public:
    int type;
    string value;
    int child_num;
    int symbol_type;
    int lineno;
    vector<ASTNode*> children;

    ASTNode(int type, int symbol_type, string value, int lineno, int child_num, ...);
    // symbol_type: 
    void printTree(int tabnum);
};
 ```

建树时完全根据syntax.y中的解析结构来建立, 所以会出现左儿子右兄弟的情况, 但是这个问题我们在这里不解决, 放到后面挨个处理. 

如果按照我们的解析规则, 最后能够解析到program这一层, 那么我们会以program为根, 递归调用分析程序进行语义分析, 如果没有得到program,则说明程序有问题, 输出not a valid program, 结束分析程序



#### 递归分析

第二步是根据得到的语法树进行递归分析, 每一个非终结符都根据自己的产生式对不同的情况进行不同的处理, 这是最繁杂的一步, 调用逻辑非常的复杂麻烦.

这是所有的递归函数的声明

```c++
void ProcessProgram(ASTNode* current_node);
void ProcessExtDefList(ASTNode* current_node);
void ProcessExtDef(ASTNode* current_node);
Type* ProcessSpecifier(ASTNode* current_node);
CPrimitive* ProcessType(ASTNode* current_node);
Type* ProcessStructSpecifier(ASTNode* current_node);

vector<CVariable*> ProcessDefList(ASTNode* current_node);
vector<CVariable*> ProcessDef(ASTNode* current_node);
vector<CVariable*> ProcessDecList(ASTNode* current_node, Type* type);

CVariable* ProcessDec(ASTNode* current_node, Type* type);
CVariable* ProcessVarDec(ASTNode* current_node, Type* type);
string ProcessID(ASTNode* current_node);
void ProcessExtDecList(ASTNode* current_node, Type* type);
CVariable* ProcessFunDec(ASTNode* current_node, Type* type);
vector<CVariable*> ProcessVarList(ASTNode* current_node);
CVariable* ProcessParamDec(ASTNode* current_node);
Type* ProcessExp(ASTNode* current_node, bool single = false);
vector<Type*> ProcessArgs(ASTNode* current_node);
void ProcessCompSt(ASTNode* current_node, Type* type);
void ProcessStmtList(ASTNode* current_node, Type* type);
void ProcessStmt(ASTNode* current_node, Type* type);
```

与此同时, 为了区分不同类别的非终结符, 定义了一系列类, 

```c++
class Type;
class CVariable;
class CStructure;
class CArray;
```

Type是基类, 其他三个为对Type的扩展, 基本涵盖了所有的变量.



### 语义分析

处理过程中, 我们会进行类型之类的比较, 然后可能发现很多问题, 一旦发现问题立刻输出报错, 同时, 我们也要存一个符号表, 每次声明或使用变量,函数, structure的时候都要先查一下符号表, 如果有重复定义, 调用不存在的变量之类的, 同样遇到这样的问题也采取立刻报错的方式

报错之后我会返回一个空类, 空类不和任何其他的类型相等, 也就是说如果有一处语义错误, 可能会导致一连串的报错, 因为任何其他变量和空类结合之后返回的值大概率还是一个空类(因为空类不在可以处理的范围内), 但报错的逻辑仍然是清晰可以信任的. 



### Bonus features

#### 1. 注释

注释在前一个project的基础上做了优化, 基本只用一行就可以处理所有可能的注释情况, 非常简洁方便

```c++
COMMENT (\/\*([^*]|[\r\n]|(\*+([^*\/]|[\r\n])))*\*+\/)|(\/\/.*)
```



### 2. 添加作用域

实际上我们会发现语义分析的遍历方式像极了深度优先搜索, 我们可以直接借鉴深度优先搜索的这一思路

我们定义一个

```c++
int global_scope_level;
```

当我们进入一个新的作用域的时候, 我们就将global_scope_level + 1, 然后新加入的变量都用这个新的level值, 我们检查冲突只检查相同level的冲突, 当我们退出作用域时, 先要清空当前作用域的变量, 然后再将global_scope_level - 1, 这样一来我们就完成了作用域的添加

