#include "translate.h"
#include <stdarg.h>
#include <unordered_map>

using namespace std;
bool debug = false;
#define LOG(x) if(debug){x;}
map<string, TAC*> tac_table;
map<string, int> active_var_table;
vector<bool> still_active;
vector<TAC*> tacs;
int info_size = 128;
void insert_tac(string name, int id){
    active_var_table[name] = id;
}
int push_tac(TAC* tac){
    int index = tacs.size();
    tacs.push_back(tac);
    
    return index;
}
int generate_label_id(){
    // 生成一个新的label_id, 指向下一个指令位置
    return tacs.size() + 1;
}

string generate_label(int label_id){
    char ss[info_size];
    sprintf(ss, "label%d", label_id);
    return ss;
}
string* generate_new_label(int label_id){
    char ss[info_size];
    sprintf(ss, "label%d", label_id);
    return new string(ss);
}

string generate_var(int var_id){
    char ss[info_size];
    sprintf(ss, "t%d", var_id);
    return ss;
}
string generate_num(int num){
    char ss[info_size];
    sprintf(ss, "#%d", num);
    return ss;
}
void replace_label(string from, string to){
    for(int i = 0; i < tacs.size(); i++){
        if(tacs[i]->tac_type == IF_TAC){
            if(tacs[i]->addr == from) tacs[i]->addr = to; 
        }
        else if(tacs[i]->tac_type == GOTO_TAC){
            if(tacs[i]->addr == from) tacs[i]->addr = to;
        }
        else if(tacs[i]->tac_type == LABEL_TAC){
            if(tacs[i]->addr == from) tacs[i]->addr = to;
        }
    }
}



void back_patch(int id, string true_list, string false_list){
    //LOG(printf("Start back patch %d\n", id))
    // 是要给某个if go 赋值, 告诉他们true_list和false_list是什么
    if(tacs[id]->inversed){
        swap(true_list, false_list);
    }
    replace_label(tacs[id]->addr, true_list);
    replace_label(tacs[id+1]->addr, false_list); 
}

void translate_Program(ASTNode* current_node){
    /*
Program:
        ExtDefList{root = new ASTNode(Program, 1, "Program", $1->lineno, 1, $1);}
        ;
    */
    translate_ExtDefList(current_node->children[0]);
}

void translate_ExtDefList(ASTNode* current_node){
/*
ExtDefList:
        ExtDef ExtDefList { $$ = new ASTNode(ExtDefList, 1, "ExtDefList", $1->lineno, 2, $1, $2);}
        | {$$ = new ASTNode(ExtDefList, 1, "ExtDefList", yylineno, 0);}
        ;
        */
       
       while(current_node->child_num > 0){
           translate_ExtDef(current_node->children[0]);
           current_node = current_node->children[1];
       }

}
void translate_ExtDef(ASTNode* current_node){
/*
ExtDef:
        Specifier ExtDecList SEMI {$$ = new ASTNode(ExtDef, 1, "ExtDef", $1->lineno, 3, $1, $2, $3);}
        | Specifier SEMI {$$ = new ASTNode(ExtDef, 1, "ExtDef", $1->lineno, 2, $1, $2);}
        | Specifier FunDec CompSt { $$ = new ASTNode(ExtDef, 1, "ExtDef", $1->lineno, 3, $1, $2, $3); }
        ;*/

        Type* type = translate_Specifier(current_node->children[0]);
        if(current_node->children[1]->type == ExtDecList){
            translate_ExtDecList(current_node->children[1], type);
        }
        else if(current_node->children[1]->type == FunDec){
            translate_FunDec(current_node->children[1], type);
            translate_CompSt(current_node->children[2]);
        }
}
Type* translate_Specifier(ASTNode* current_node){
    /*
    Specifier:
        TYPE {$$ = new ASTNode(Specifier, 1, "Specifier", $1->lineno, 1, $1);}
        | StructSpecifier {$$ = new ASTNode(Specifier, 1, "Specifier", $1->lineno, 1, $1);}
        ;*/
    // 这个由于设定问题应该默认返回int值
    Type* type;
    if(current_node->children[0]->type == T_TYPE){
        type = translate_Type(current_node->children[0]);
    }
    else{
        //type = translate_StructSpecifier(current_node->children[0]);
    }
}
Type* translate_Type(ASTNode* current_node){
    // 这里应该是只有int吧
    return ProcessType(current_node);
}


void translate_DefList(ASTNode* current_node){
    /*DefList:
        Def DefList { $$ = new ASTNode(DefList, 1, "DefList", $1->lineno, 2, $1, $2);}
        |  {$$ = new ASTNode(DefList, 1, "DefList", yylineno, 0); }
        ;*/
    while(current_node->child_num > 0){
        translate_Def(current_node->children[0]);
        current_node = current_node->children[1];
    }
}
void translate_Def(ASTNode* current_node){
    /*
    Def:
        Specifier DecList SEMI {$$ = new ASTNode(Def, 1, "Def", $1->lineno, 3, $1, $2, $3); }
        ;*/
    Type* type = translate_Specifier(current_node->children[0]);
    translate_DecList(current_node->children[1], type);
}

void translate_DecList(ASTNode* current_node, Type* type){
    /*
    DecList:
        Dec { $$ = new ASTNode(DecList, 1, "DecList", $1->lineno, 1, $1);}
        | Dec COMMA DecList {$$ = new ASTNode(DecList, 1, "DecList", $1->lineno, 3, $1, $2, $3); }
        ;*/
    translate_Dec(current_node->children[0], type);
    while(current_node->child_num > 1){
        current_node = current_node->children[2];
        translate_Dec(current_node->children[0], type);
    }
}
void translate_Dec(ASTNode* current_node, Type* type){
/*
Dec:
        VarDec {$$ = new ASTNode(Dec, 1, "Dec", $1->lineno, 1, $1); }
        | VarDec ASSIGN Exp {$$ = new ASTNode(Dec, 1, "Dec", $1->lineno, 3, $1, $2, $3); }
    ;*/
    int id = 0;
    if(current_node->child_num > 1){
        id = translate_Exp(current_node->children[2]);
    }
    TAC* tac = translate_VarDec(current_node->children[0], type);
    if(id != 0){
        dynamic_cast<AssignTac*>(tac)->raddr1 = tacs[id]->addr;
    }
    int index = push_tac(tac);

    insert_tac(tac->name, index);
}

TAC* translate_VarDec(ASTNode* current_node, Type* type){
    /*
    VarDec:
        VarDec LB INT RB {$$ = new ASTNode(VarDec, 1, "VarDec", $1->lineno, 4, $1, $2, $3, $4);}
        | ID {$$ = new ASTNode(VarDec, 1, "VarDec", $1->lineno, 1, $1);}
    */
    // 放弃治疗, 这里只有ID声明这一种可能
   TAC* tac = new AssignTac(tacs.size(), generate_var(tacs.size()), generate_num(0));
    tac->name = current_node->children[0]->value;
    //LOG(printf("Declare: %s\n", tac->name.c_str()))
    return tac;
}
void translate_ExtDecList(ASTNode* current_node, Type* type){
    /*ExtDecList:
        VarDec { $$ = new ASTNode(ExtDecList, 1, "ExtDecList", $1->lineno, 1, $1);}
        | VarDec COMMA ExtDecList {$$ = new ASTNode(ExtDecList, 1, "ExtDecList", $1->lineno, 3, $1, $2, $3);}
        ;*/
    TAC* tac = translate_VarDec(current_node->children[0], type);
    insert_tac(tac->name, push_tac(tac));
    while(current_node->child_num > 1){
        current_node = current_node->children[2];
        TAC* tac = translate_VarDec(current_node->children[0], type);
        insert_tac(tac->name, push_tac(tac));
    }

}
void translate_FunDec(ASTNode* current_node, Type* type){
    /*
    FunDec:
        ID LP VarList RP { $$ = new ASTNode(FunDec, 1, "FunDec", $1->lineno, 4, $1, $2, $3, $4);}
        | ID LP RP {$$ = new ASTNode(FunDec, 1, "FunDec", $1->lineno, 3, $1, $2, $3); }
        ;*/
    
    /*
    Function main:
    param t1
    param t2 
    etc
    */
    string name = current_node->children[0]->value;

    int fundec = push_tac(new FunctionTac(tacs.size(), name));
    insert_tac(name, fundec);
    
    if(current_node->children[2]->type == VarList){
        translate_VarList(current_node->children[2]);
    }
    
}
void translate_VarList(ASTNode* current_node){
    /*
    VarList:
        ParamDec COMMA VarList {$$ = new ASTNode(VarList, 1, "VarList", $1->lineno, 3, $1, $2, $3);}
        | ParamDec { $$ = new ASTNode(VarList, 1, "VarList", $1->lineno, 1, $1);}
        ;
    */
    vector<ASTNode*> stack;
    stack.push_back(current_node->children[0]);
    while(current_node->child_num > 1){
        current_node = current_node->children[2];
        stack.push_back(current_node->children[0]);
    }
    while(!stack.empty()){
        translate_ParamDec(stack.back());
        stack.pop_back();
    }
}
void translate_ParamDec(ASTNode* current_node){
    /*
    ParamDec:
        Specifier VarDec {$$ = new ASTNode(ParamDec, 1, "ParamDec", $1->lineno, 2, $1, $2);}
        ;
*/
    Type* type = translate_Specifier(current_node->children[0]);
    // 这里几乎没啥用, 但还是按照流程搞一波
    TAC* tac = translate_VarDec(current_node->children[1], type);
    // here, we only get assignTac because of assumption
    if(tac->tac_type == ASSIGN_TAC){
        insert_tac(tac->name, push_tac(new ParamTac(tacs.size(), generate_var(tacs.size()))));
        return;
    }
    //LOG(printf("Something wrong happened\n"))
}

int translate_Exp(ASTNode* current_node, bool is_left_value){
    // 返回的应该是解析出来的对应的表达的存值的地址
    /*Exp:
        Exp ASSIGN Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp AND Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp OR Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp LT Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp LE Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp GT Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp GE Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp NE Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp EQ Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp ADD Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp SUB Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp MUL Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        | Exp DIV Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
        
        | LP Exp RP {$$ = $2; }
        | SUB Exp {$$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 2, $1, $2); }
        | NOT Exp {$$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 2, $1, $2);}
        
        
        | Exp LB Exp RB {$$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 4, $1, $2, $3, $4);}
        | Exp DOT ID {$$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3);}

        | ID {$$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 1, $1); }
        | INT { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 1, $1); }
        | READ LP RP {$$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3);}
        ;*/
    // read

    if(current_node->children[0]->type == T_READ){
        ReadTac* tac = new ReadTac(tacs.size(), generate_var(tacs.size()));
        push_tac(tac);
        return tac->id;
    }
    // INT
    if(current_node->children[0]->type == T_INT){
        AssignTac* tac = new AssignTac(tacs.size(), generate_var(tacs.size()), generate_num(atoi(current_node->children[0]->value.c_str())));
        push_tac(tac);
        return tac->id;
    }
    if(current_node->children[0]->type == T_SUB){
        // 负数
        int id = translate_Exp(current_node->children[1]);
        ArithmeticTac* tac = new ArithmeticTac(tacs.size(), generate_var(tacs.size()), generate_num(0), T_SUB,  tacs[id]->addr);
        push_tac(tac);
        return tac->id;
    }
    if(current_node->children[0]->type == T_NOT){
        // 这里有问题, 还需要继续修
        int id = translate_Exp(current_node->children[1]);
        tacs[id]->inversed = !(tacs[id]->inversed);
        return id;
    }
    // 函数调用
    //    | ID LP Args RP {$$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 4, $1, $2, $3, $4);}
    //    | ID LP RP {$$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3);}
    if(current_node->children[0]->type == T_ID && current_node->child_num > 1){
        string name = current_node->children[0]->value;
        if(current_node->children[2]->type == Args){
            vector<int> args = translate_Args(current_node->children[2]);
            for(int id : args){
                push_tac(new ArgTac(tacs.size(), tacs[id]->addr));
            }
        }
        int id = push_tac(new CallTac(tacs.size(), generate_var(tacs.size()), name));
        return id;
    }
    else if(current_node->children[0]->type == T_ID){
        // 这里要等等看
        
        string name = current_node->children[0]->value;
        int id = active_var_table[name];
        //LOG(printf("find %s %d\n", name.c_str(), id))
        if(is_left_value){
            // 如果是左值的话, 这里要被重新赋值, 覆盖掉之前的东西
            if(!id){
                id = tacs.size();
                insert_tac(name, id);
            }
            return push_tac(new AssignTac(tacs.size(), generate_var(id), generate_num(0)));
        }
        else if(!id){
            //LOG(printf("Create new id for %s\n", name.c_str()))

            insert_tac(name, tacs.size());
            return push_tac(new AssignTac(tacs.size(), generate_var(tacs.size()), generate_num(0)));
        }
        else{
            return id;
        }
    }
    //留下来一会儿写
    //| Exp OR Exp { $$ = new ASTNode(Exp, 1, "Exp", $1->lineno, 3, $1, $2, $3); }
    if(current_node->children[1]->type == T_OR){
        int left_id = translate_Exp(current_node->children[0]);
        int id = push_tac(new LabelTac(tacs.size(), generate_label(tacs.size())));
        LabelTac* mid_label = dynamic_cast<LabelTac*>(tacs[id]);
        int left_inversed = tacs[left_id]->inversed;
        int right_id = translate_Exp(current_node->children[2]);
        int right_inversed = tacs[right_id]->inversed;
        IfTac* left_if = dynamic_cast<IfTac*>(tacs[left_id]);
        GotoTac* left_goto = dynamic_cast<GotoTac*>(tacs[left_id+1]);
        IfTac* right_if = dynamic_cast<IfTac*>(tacs[right_id]);
        GotoTac* right_goto = dynamic_cast<GotoTac*>(tacs[right_id+1]);


        if(left_inversed){
            replace_label(left_if->addr, mid_label->addr);
            if(right_inversed){
               replace_label(right_goto->addr, left_goto->addr);
            }else{
                replace_label(right_if->addr, left_goto->addr);
            }
        }
        else{
            replace_label(left_goto->addr, mid_label->addr);
            if(right_inversed){
                replace_label(right_goto->addr, left_if->addr);
            }
            else{
                replace_label(right_if->addr, left_if->addr);
            }
        }
        return right_id;
    }
    if(current_node->children[1]->type == T_AND){
        int left_id = translate_Exp(current_node->children[0]);
        int id = push_tac(new LabelTac(tacs.size(), generate_label(tacs.size())));
        LabelTac* mid_label = dynamic_cast<LabelTac*>(tacs[id]);
        int left_inversed = tacs[left_id]->inversed;
        int right_id = translate_Exp(current_node->children[2]);
        int right_inversed = tacs[right_id]->inversed;

        IfTac* left_if = dynamic_cast<IfTac*>(tacs[left_id]);
        GotoTac* left_goto = dynamic_cast<GotoTac*>(tacs[left_id+1]);
        IfTac* right_if = dynamic_cast<IfTac*>(tacs[right_id]);
        GotoTac* right_goto = dynamic_cast<GotoTac*>(tacs[right_id+1]);
        
        if(left_inversed){
            replace_label(left_goto->addr, mid_label->addr);
            if(right_inversed){
                replace_label(right_if->addr, left_if->addr);
            }
            else{
                replace_label(right_goto->addr, left_if->addr);
            }
        }
        else{
            replace_label(left_if->addr, mid_label->addr);
            if(right_inversed){
                replace_label(right_if->addr, left_goto->addr);
            }
            else{
                replace_label(right_goto->addr, left_goto->addr);
            }
        }
        return right_id;
    }
    // 六个比较
    if(current_node->children[1]->type == T_LT || 
    current_node->children[1]->type == T_LE || 
    current_node->children[1]->type == T_GT || 
    current_node->children[1]->type == T_GE || 
    current_node->children[1]->type == T_EQ || 
    current_node->children[1]->type == T_NE){
        /*
        exp1
        exp2
        if goto truelist
        goto falselist
        return if_id
        */

        int left_id = translate_Exp(current_node->children[0]);
        int right_id = translate_Exp(current_node->children[2]);
        IfTac* if_tac = new IfTac(tacs.size(), generate_label(tacs.size()) , tacs[left_id]->addr, 
            Token(current_node->children[1]->type), tacs[right_id]->addr);
        int if_id = push_tac(if_tac);
        TAC* goto_tac = new GotoTac(tacs.size(), generate_label(tacs.size()));
        int goto_id = push_tac(goto_tac);
        return if_id;
    }
    
    if(current_node->children[1]->type == T_ASSIGN){
        int right_id = translate_Exp(current_node->children[2]);
        int left_id = translate_Exp(current_node->children[0], true);
        if(tacs[left_id]->tac_type == ASSIGN_TAC){
            //LOG(printf("bug find: %d\n", left_id))
            LOG(printf("assign %s %s\n", tacs[left_id]->addr.c_str(), tacs[right_id]->addr.c_str()))
            dynamic_cast<AssignTac*>(tacs[left_id])->raddr1 = tacs[right_id]->addr;
        }
        else{
            // 剩下的不管了, 并没有其他assign的功能
        }
        // 这里应该是返回left, 但是assign应该不允许独立出现以外的情况, 就还可以
        return left_id;
    }
    if(current_node->children[1]->type == T_ADD ||
     current_node->children[1]->type == T_SUB ||
     current_node->children[1]->type == T_MUL ||
     current_node->children[1]->type == T_DIV){
         int left_id = translate_Exp(current_node->children[0]);
         int right_id = translate_Exp(current_node->children[2]);
         ArithmeticTac* tac = new ArithmeticTac(tacs.size(), generate_var(tacs.size()), tacs[left_id]->addr, Token(current_node->children[1]->type), tacs[right_id]->addr);
         return push_tac(tac);
     }
}
vector<int> translate_Args(ASTNode* current_node){
    /*
    Args: Exp COMMA Args {$$ = new ASTNode(Args, 1, "Args", $1->lineno, 3, $1, $2, $3);}
        | Exp { $$ = new ASTNode(Args, 1, "Args", $1->lineno, 1, $1);}
      */
    
    vector<int> args;
    int id = translate_Exp(current_node->children[0]);
    args.push_back(id);
    while(current_node->child_num > 1){
        current_node = current_node->children[2];
        id = translate_Exp(current_node->children[0]);
        args.push_back(id);
    }
    return args;
}
void translate_CompSt(ASTNode* current_node){
/*CompSt:
        LC DefList StmtList RC { $$ = new ASTNode(CompSt, 1, "CompSt", $1->lineno, 4, $1, $2, $3, $4);}
        ;*/
        translate_DefList(current_node->children[1]);
        
        translate_StmtList(current_node->children[2]);

}
void translate_StmtList(ASTNode* current_node){
/*StmtList:
        Stmt StmtList {$$ = new ASTNode(StmtList, 1, "StmtList", $1->lineno, 2, $1, $2); }
        | {$$ = new ASTNode(StmtList, 1, "StmtList", yylineno, 0);}
        ;*/
        while(current_node->child_num > 0){
            
            translate_Stmt(current_node->children[0]);
            current_node = current_node->children[1];
        }
}
void translate_Stmt(ASTNode* current_node){
/*
Stmt: 
        Exp SEMI {$$ = new ASTNode(Stmt, 1, "Stmt", $1->lineno, 2, $1, $2);}
        | CompSt { $$ = new ASTNode(Stmt, 1, "Stmt", $1->lineno, 1, $1);}
        | RETURN Exp SEMI { $$ = new ASTNode(Stmt, 1, "Stmt", $1->lineno, 3, $1, $2, $3); }
        
        | IF LP Exp RP Stmt { $$ = new ASTNode(Stmt, 1, "Stmt", $1->lineno, 5, $1, $2, $3, $4, $5);}
        | IF LP Exp RP Stmt ELSE Stmt {$$ = new ASTNode(Stmt, 1, "Stmt", $1->lineno, 7, $1, $2, $3, $4, $5, $6, $7);}
        
        
        | WHILE LP Exp RP Stmt { $$ = new ASTNode(Stmt, 1, "Stmt", $1->lineno, 5, $1, $2, $3, $4, $5);}
        | WRITE LP Args RP SEMI {$$ = new ASTNode(Stmt, 1, "Stmt", $1->lineno, 5, $1, $2, $3, $4, $5);}
        ;*/
        
        if(current_node->children[0]->type == Exp){
            translate_Exp(current_node->children[0]);
        }
        else if(current_node->children[0]->type == CompSt){
            translate_CompSt(current_node->children[0]);
        }
        else if(current_node->children[0]->type == T_RETURN){
            int id = translate_Exp(current_node->children[1]);
            push_tac(new ReturnTac(tacs.size(), tacs[id]->addr));
            LOG(printf("Return down\n"))
            //LOG(printf("%s\n", tacs[tacs.size()-1]->to_string().c_str()))
        }
        else if(current_node->children[0]->type == T_IF){
            //LOG(printf("If start\n"))
            // 这里是有问题的, IF
            int id = translate_Exp(current_node->children[2]);
            // 判断通过走这里
            //LOG(printf("Start to label true\n"))
            IfTac* if_tac = dynamic_cast<IfTac*>(tacs[id]);
            int true_list = push_tac(new LabelTac(tacs.size(), tacs[id]->addr));
            translate_Stmt(current_node->children[4]);
            // 判断不通过走这里
            // jump 这里是在干什么呢?
            int jump_id = 0;
            // 第一段运行完之后跳转到的位置
            if(current_node->child_num > 5){
                jump_id = push_tac(new GotoTac(tacs.size(), generate_label(tacs.size())));
            }

            GotoTac* goto_tac = dynamic_cast<GotoTac*>(tacs[id+1]);
            int false_list = push_tac(new LabelTac(tacs.size(), tacs[id+1]->addr));
            // back patch
            back_patch(id, if_tac->addr, goto_tac->addr);
            
            if(current_node->child_num > 5){
                translate_Stmt(current_node->children[6]);
                int jump_target = push_tac(new LabelTac(tacs.size(), generate_label(tacs.size())));
                replace_label(dynamic_cast<GotoTac*>(tacs[jump_id])->addr, dynamic_cast<LabelTac*>(tacs[jump_target])->addr);
            }
        }
        else if(current_node->children[0]->type == T_WHILE){
            // | WHILE LP Exp RP Stmt { $$ = new ASTNode(Stmt, 1, "Stmt", $1->lineno, 5, $1, $2, $3, $4, $5);}
           
            int while_start_id = push_tac(new LabelTac(tacs.size(), generate_label(tacs.size())));
            int id = translate_Exp(current_node->children[2]);
            //LOG(printf("%s\n", tacs[id]->to_string().c_str()))
            int true_list = push_tac(new LabelTac(tacs.size(), generate_label(tacs.size())));
            translate_Stmt(current_node->children[4]);
            int loop_back_id = push_tac(new GotoTac(tacs.size(), generate_label(while_start_id)));
            int false_list = push_tac(new LabelTac(tacs.size(), generate_label(tacs.size())));
            back_patch(id, (tacs[true_list]->addr), (tacs[false_list]->addr));
        }
        else if(current_node->children[0]->type == T_WRITE){
            //LOG(printf("Write\n"))
            auto args = translate_Args(current_node->children[2]);
            for(auto id : args){
                push_tac(new WriteTac(tacs.size(), tacs[id]->addr));
            }
        }

    
}
struct Var_Freq{
    int line_no;
    int freq;
    string value;
};


bool op1(){
    bool change = false;
    still_active.clear();
    for(auto i : tacs){
        still_active.push_back(true);
    }
    unordered_map<string, Var_Freq> temp_map;
    for(int i = 0; i < tacs.size(); i++){
        if(tacs[i]->tac_type == ASSIGN_TAC){
            
            AssignTac* assign_temp = dynamic_cast<AssignTac*>(tacs[i]);
            
            if(assign_temp->raddr1[0] == '#'){
                if(temp_map.find(assign_temp->addr) == temp_map.end()){
                    temp_map[assign_temp->addr] = {i, 1, assign_temp->raddr1};
                }
                else{
                    temp_map[assign_temp->addr] = {i, 2, assign_temp->raddr1};
                }
            }
            else{
                temp_map[assign_temp->addr] = {i, 3, assign_temp->raddr1};
            }
        }
    }
    for(auto it : temp_map){
        if(it.second.freq == 1){
            //printf("%s\n", it.first.c_str());
            still_active[it.second.line_no] = false;
            change = true;
            for(auto tac : tacs){
                if(tac->addr == it.first){
                    tac->addr = it.second.value;
                }
                if(tac->raddr1 == it.first){
                    tac->raddr1 = it.second.value;
                }if(tac->raddr2 == it.first){
                    tac->raddr2 = it.second.value;
                }
            }
        }
        
    }

    vector<TAC*> temp_tacs = tacs;
    tacs.clear();
    for(int i = 0; i < temp_tacs.size(); i++){
        if(still_active[i]){
            tacs.push_back(temp_tacs[i]);
        }
    }
    return change;
}
void op2(){
    // 删除重复的label
    
    still_active.clear();
    for(auto i : tacs){
        still_active.push_back(true);
    }
    LabelTac* last_label = nullptr;
    for(int i = 0; i < tacs.size(); i++){
        if(tacs[i]->tac_type == LABEL_TAC){
            if(last_label){
                still_active[i] = false;
                replace_label(tacs[i]->addr, last_label->addr);
            }else{
                last_label = dynamic_cast<LabelTac*>(tacs[i]);
            }
        }
        else{
            last_label = nullptr;
        }
    }
    vector<TAC*> temp_tacs = tacs;
    tacs.clear();
    for(int i = 0; i < temp_tacs.size(); i++){
        if(still_active[i]){
            tacs.push_back(temp_tacs[i]);
        }
    }
}



void generate_tacs(ASTNode* current_node){
    
    translate_Program(current_node);
    // 该优化了,
    // 首先是把从来没用过的变量替换掉
    
    
    for(auto i : tacs){
        still_active.push_back(true);
    }
    while(op1()){}
    
    op2();
    for(int i = 0; i < tacs.size(); i++){
        fprintf(FILE_OUT, "%s\n", tacs[i]->to_string().c_str());
    }

}
