#include "semantic.h"
#include <vector>
#include "string.h"
#include <string>

class TAC;
extern int info_size;
// 存储最终的一系列三地址码
extern vector<TAC*> tacs;
extern map<string, int> active_var_table;
enum TAC_TYPE{
    LABEL_TAC,
    FUNCTION_TAC,
    ASSIGN_TAC, 
    ARITHMETIC_TAC, 
    GOTO_TAC, 
    IF_TAC,
    RETURN_TAC,
    PARAM_TAC,
    ARG_TAC,
    CALL_TAC, 
    READ_TAC,
    WRITE_TAC
};
class TAC{
public:
    int id;
    string addr;
    string raddr1;
    string raddr2;
    bool inversed = false;
    string name;
    Type* type;
    TAC_TYPE tac_type;
    TAC(){}
    TAC(int id, string addr, TAC_TYPE tac_type):id(id), addr(addr), tac_type(tac_type){}
    TAC(int id, string addr, string raddr1, TAC_TYPE tac_type):id(id), addr(addr), raddr1(raddr1),tac_type(tac_type){}
    TAC(int id, string addr, string raddr1, string raddr2, TAC_TYPE tac_type):id(id), addr(addr), raddr1(raddr1), raddr2(raddr2), tac_type(tac_type){}
    virtual string to_string(){
        return "";
    }
};

class LabelTac : public TAC{
// define a label x, 命名为label所在的address
// label所代表的label名字
public:
    string to_string(){
        char ss[info_size];
        sprintf(ss, "LABEL %s :", addr.c_str());
        return ss;
    }
    LabelTac(int id, string addr): TAC(id, addr, LABEL_TAC){}
};
class FunctionTac : public TAC{
//FUNCTION f: define a function f
// addr 代表function的名字
public:
    string to_string(){
        char ss[info_size];
        sprintf(ss, "FUNCTION %s :", addr.c_str());
        return ss;
    }
    FunctionTac(int id, string function)
        : TAC(id, function, FUNCTION_TAC){}
};

class AssignTac : public TAC{
    //右边只有一个addr1
public:
    string to_string(){
        char ss[info_size];
        sprintf(ss, "%s := %s", addr.c_str(), raddr1.c_str());
        return ss;
    }
    AssignTac(int id, string addr, string raddr) : TAC(id, addr, raddr, ASSIGN_TAC){}
};

class ArithmeticTac : public TAC{
public:
    
    string op;
    string to_string(){
        char ss[info_size];
        sprintf(ss, "%s := %s %s %s", addr.c_str(), raddr1.c_str(), op.c_str(), raddr2.c_str());
        return ss;
    }
    ArithmeticTac(int id, string addr, string raddr1, Token op_token, string raddr2)
     : TAC(id, addr, raddr1, raddr2,  ARITHMETIC_TAC){
         switch (op_token)
         {
         case T_ADD:
             op = "+";
             break;
         case T_SUB:
            op = "-";
            break;
        case T_MUL:
            op = "*";
            break;
        case T_DIV:
            op = "/";
            break;
         default:
            printf("Wrong operator!!!!\n");
            break;
         }
     }
};
//GOTO x
class GotoTac : public TAC{
public:
    string to_string(){
        char ss[info_size];
        sprintf(ss, "GOTO %s", addr.c_str());
        return ss;
    }
    GotoTac(int id, string addr): TAC(id, addr, GOTO_TAC){}
};
//IF x [relop] y GOTO z
class IfTac : public TAC{
public:
    string op;
    string to_string(){
        char ss[info_size];
        sprintf(ss, "IF %s %s %s GOTO %s", raddr1.c_str(), op.c_str(), raddr2.c_str(), addr.c_str());
        return ss;
    }
    IfTac(int id, string addr, string raddr1, Token op_token, string raddr2)
    :TAC(id, addr, raddr1, raddr2,IF_TAC){
        switch (op_token)
        {
        case T_LT:
            op = "<";
            break;
        case T_LE:
            op = "<=";
            break;
        case T_GT:
            op = ">";
            break;
        case T_GE:
            op = ">=";
            break;
        case T_EQ:
            op = "==";
            break;
        case T_NE:
            op = "!=";
            break;
        default:
            break;
        }
    }
};
// RETURN x
class ReturnTac : public TAC{
public:
    int raddr;
    string to_string(){
        char ss[info_size];
        sprintf(ss, "RETURN %s",addr.c_str());
        return ss;
    }
    ReturnTac(int id, string addr)
     : TAC(id, addr, RETURN_TAC){
        
     }
};

//PARAM x
class ParamTac: public TAC{
public:

    string to_string(){
        char ss[info_size];
        sprintf(ss, "PARAM %s", addr.c_str());
        return ss;
    }
    ParamTac(int id, string addr)
    : TAC(id, addr, PARAM_TAC){
    }
};
//ARG x
class ArgTac : public TAC{
public:
    string to_string(){
        char ss[info_size];
        sprintf(ss, "ARG %s", addr.c_str());
        return ss;
    }
    ArgTac(int id, string addr) : TAC(id, addr, ARG_TAC){}
};
//x := CALL f
class CallTac : public TAC{
public:
    string to_string(){
        char ss[info_size];
        sprintf(ss, "%s := CALL %s", addr.c_str(), raddr1.c_str());
        return ss;
    }
    CallTac(int id, string addr, string label) : TAC(id, addr, label, CALL_TAC){}
};
//READ x
class ReadTac : public TAC{
public:
    string to_string(){
        char ss[info_size];
        sprintf(ss, "READ %s", addr.c_str());
        return ss;
    }
    ReadTac(int id, string addr) : TAC(id, addr, READ_TAC){}
};
// WRITE x
class WriteTac : public TAC{
public:
    string to_string(){
        char ss[info_size];
        sprintf(ss, "WRITE %s", addr.c_str());
        return ss;
    }
    WriteTac(int id, string addr) : TAC(id, addr, WRITE_TAC){}
};

void generate_tacs(ASTNode* current_node);

void translate_Program(ASTNode* current_node);
void translate_ExtDefList(ASTNode* current_node);
void translate_ExtDef(ASTNode* current_node);
Type* translate_Specifier(ASTNode* current_node);
Type* translate_Type(ASTNode* current_node);

void translate_DefList(ASTNode* current_node);
void translate_Def(ASTNode* current_node);
void translate_DecList(ASTNode* current_node, Type* type);
void translate_Dec(ASTNode* current_node, Type* type);

TAC* translate_VarDec(ASTNode* current_node, Type* type);
void translate_ExtDecList(ASTNode* current_node, Type* type);
void translate_FunDec(ASTNode* current_node, Type* type);
void translate_VarList(ASTNode* current_node);
void translate_ParamDec(ASTNode* current_node);

int translate_Exp(ASTNode* current_node, bool is_left_value = false);
vector<int> translate_Args(ASTNode* current_node);
void translate_CompSt(ASTNode* current_node);
void translate_StmtList(ASTNode* current_node);
void translate_Stmt(ASTNode* current_node);
