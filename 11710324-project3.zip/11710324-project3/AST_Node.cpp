#include "AST_Node.h"
#include <stdarg.h>
using namespace std;


FILE* FILE_OUT;
FILE* FILE_IN;

ASTNode::ASTNode(int type, int symbol_type, string value, int lineno, int child_num, ...)
    :type(type), symbol_type(symbol_type), value(value), 
    child_num(child_num), lineno(lineno)
{
    
    children = vector<ASTNode*>();
    if(type == T_ID || type == T_TYPE){
        //cout << this->value << " " << lineno << endl;
    }
    
    va_list args;
    va_start(args, child_num);
    while(child_num--){
        ASTNode* node = va_arg(args, ASTNode*);
        ASTNode* new_node = new ASTNode(*node);
    
        this->children.push_back(new_node);
    }
}
void ASTNode::printTree(int tabnum){
    printf("OK, I will do my work\n");
}
