make clean
make splc
bin/splc test/test_3_r01.spl
bin/splc test/test_3_r02.spl
bin/splc test/test_3_r03.spl
bin/splc test/test_3_r04.spl
bin/splc test/test_3_r05.spl
bin/splc test/test_3_r06.spl
bin/splc test/test_3_r07.spl
bin/splc test/test_3_r08.spl
bin/splc test/test_3_r09.spl
bin/splc test/test_3_r10.spl
bin/splc sample/test_m1.spl

simulator/irsim_linux-x86_64/dist/irsim sample/test_m1.out
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r01.out
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r02.out -i 2020,2
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r02.out -i 1900,2
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r02.out -i 2100,3
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r02.out -i 2100,4
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r02.out -i 1999,4
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r02.out -i 1999,2

simulator/irsim_linux-x86_64/dist/irsim test/test_3_r03.out
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r04.out -i 3
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r05.out -i 9
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r05.out -i 10
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r05.out -i 11


simulator/irsim_linux-x86_64/dist/irsim test/test_3_r06.out
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r07.out -i 25,5
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r07.out -i 9,81

simulator/irsim_linux-x86_64/dist/irsim test/test_3_r08.out -i 12345

simulator/irsim_linux-x86_64/dist/irsim test/test_3_r09.out
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r10.out -i 9
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r10.out -i -9
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r10.out -i 0