make clean
make splc
bin/splc test/test_3_r03.spl
simulator/irsim_linux-x86_64/dist/irsim test/test_3_r03.out